<?php
ini_set('display_errors', 0);
require_once('TwitterAPIExchange.php');

$name = $_POST['Twittername'];
if($name!="")
$texthide = 1;
else
$texthide = 0;
//echo $name;

/** Set access tokens here - see: https://dev.twitter.com/apps/ **/
$settings = array(
    'oauth_access_token' => "219177712-qmUbF1eGjiKE9aLLd1DMmxMuitrbKlva0aH8KKfr",
    'oauth_access_token_secret' => "0YCCSuhMGu4vMKYJsp89W08lchnXEnLpZtqh8j8RihD4Z",
    'consumer_key' => "NNdfbQU1eU5CGqk3k0ns8YLb1",
    'consumer_secret' => "wa2tSF2Yo6PLrSihmqhqJvoQqxLUekxZSPkjnzKbVDk7PldXmC"
);

/** URL for REST request, see: https://dev.twitter.com/docs/api/1.1/ **/
$url = 'https://api.twitter.com/1.1/blocks/create.json';
$requestMethod = 'POST';

/** POST fields required by the URL above. See relevant docs as above **/
/*$postfields = array(
    'screen_name' => 'maniforu87', 
    'skip_status' => '1'
);*/

/** Perform a POST request and echo the response **/
/*$twitter = new TwitterAPIExchange($settings);
echo $twitter->buildOauth($url, $requestMethod)
             ->setPostfields($postfields)
             ->performRequest();

/** Perform a GET request and echo the response **/
/** Note: Set the GET field BEFORE calling buildOauth(); **/
$m = array();
for ($y = 1; $y <= 2; $y++) {
$url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
$getfield = 'include_entities=true&include_rts=true&screen_name='.$name.'&count=200&page='.$y;
$requestMethod = 'GET';

$twitter = new TwitterAPIExchange($settings);
$response = $twitter->setGetfield($getfield)
    ->buildOauth($url, $requestMethod)
    ->performRequest();
array_push($m, $response);
}
//echo "<pre>";print_r($m);
	//echo count($response[text]);
	
	//$final_tweet = json_decode($response);
	
	//$final_tweet = json_decode($m, true);
	
	//echo "<pre>";print_r($final_tweet);
	//print_r($final_tweet);
	//echo count($m);
	$food=0;
	$travel=0;
	$entertainment=0;
	$expenses=0;
	for ($x = 0; $x <= count($m); $x++) {
    $final_tweet = json_decode($m[$x],true);
	
	
	for ($k = 0; $k <= count($final_tweet); $k++) {
		if (preg_match('/food|hotel|eating|dining|party/i',$final_tweet[$k][text])) {
		$food++;
	} else if(preg_match('/going|bus|trip|train|flight|meet/i',$final_tweet[$k][text])) {
		$travel++;
	} else if(preg_match('/movies|sports|cricket|football/i',$final_tweet[$k][text])) {
		$entertainment++;
	} else if(preg_match('/money|bank|transfer|purchase|paid|bought|india/i',$final_tweet[$k][text])) {
		$expenses++;
	}
	}

	
	}
	
$myObj->food = $food;
$myObj->travel = $travel;
$myObj->entertainment = $entertainment;
$myObj->expenses = $expenses;

$myJSON = json_encode($myObj);

//echo $myJSON;
	
?>
<html>
  <head>
    <script type="text/javascript"
src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
		  
		  var food = parseInt(document.getElementById("food").value);
		  var travel=parseInt(document.getElementById("travel").value);
		  var entertainment=parseInt(document.getElementById("entertainment").value);
		  var expenses=parseInt(document.getElementById("expenses").value);
		  var texthide=parseInt(document.getElementById("texthide").value);
			if(texthide==1){
				 var data = google.visualization.arrayToDataTable([
          ['Topic', 'Spending'],
          ['Travel',     food],
          ['Food',      travel],
          ['Entertainment',  entertainment],
          ['Expenses', expenses]
        
        ]);

        var options = {
          title: 'Spending Patterns'
        };

        var chart = new
google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
			}
			
       
      }
    </script>
  </head>
  <body>
  <form action="index.php" method="post">
Twitter name: <input type="text" name="Twittername"><br>
<input type="submit">
</form>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
	<input type="hidden" value="<?php echo $food;?>" id="food"/>
	<input type="hidden" value="<?php echo $travel;?>" id="travel"/>
	<input type="hidden" value="<?php echo $entertainment;?>" id="entertainment"/>
	
	<input type="hidden" value="<?php echo $texthide;?>" id="texthide"/>
	
	<input type="hidden" value="<?php echo $expenses;?>" id="expenses"/>
	
  </body>
</html>


