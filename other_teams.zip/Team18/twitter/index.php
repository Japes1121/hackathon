<?php
ini_set('display_errors', 0);
require_once('TwitterAPIExchange.php');
$name = $_POST['Twittername'];
if($name!="")
$texthide = 1;
else
$texthide = 0;
//echo $name;

/** Set access tokens here - see: https://dev.twitter.com/apps/ **/
$settings = array(
    'oauth_access_token' => "219177712-qmUbF1eGjiKE9aLLd1DMmxMuitrbKlva0aH8KKfr",
    'oauth_access_token_secret' => "0YCCSuhMGu4vMKYJsp89W08lchnXEnLpZtqh8j8RihD4Z",
    'consumer_key' => "NNdfbQU1eU5CGqk3k0ns8YLb1",
    'consumer_secret' => "wa2tSF2Yo6PLrSihmqhqJvoQqxLUekxZSPkjnzKbVDk7PldXmC"
);

/** URL for REST request, see: https://dev.twitter.com/docs/api/1.1/ **/
$url = 'https://api.twitter.com/1.1/blocks/create.json';
$requestMethod = 'POST';


$m = array();
for ($y = 1; $y <= 10; $y++) {
$url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
$getfield = 'include_entities=true&include_rts=true&screen_name='.$name.'&count=200&page='.$y;
$requestMethod = 'GET';

$twitter = new TwitterAPIExchange($settings);
$response = $twitter->setGetfield($getfield)
    ->buildOauth($url, $requestMethod)
    ->performRequest();
array_push($m, $response);
}

	$food=0;
	$travel=0;
	$entertainment=0;
	$expenses=0;
	$food_expenses=0;
	$travel_expenses=0;
	$entertainment_expenses=0;
	$date_expenses=0;
	$str = '';
	for ($x = 0; $x <= count($m); $x++) {
    $final_tweet = json_decode($m[$x],true);
	
	
	for ($k = 0; $k <= count($final_tweet); $k++) {
		//echo "<pre>";
		
	
	if (preg_match('/food|hotel|eating|dining|party/i',$final_tweet[$k][text])) {
		$food++;
		$food_expenses .= substr($final_tweet[$k][created_at],3,4).",";
	} else if(preg_match('/going|bus|trip|train|flight|meet|travel/i',$final_tweet[$k][text])) {
		$travel++;
		$travel_expenses .= substr($final_tweet[$k][created_at],3,4).",";
	} else if(preg_match('/movies|sports|cricket|football/i',$final_tweet[$k][text])) {
		$entertainment++;
		$entertainment_expenses .= substr($final_tweet[$k][created_at],3,4).",";	
	} else if(preg_match('/money|bank|transfer|purchase|paid|bought|india/i',$final_tweet[$k][text])) {
		$expenses++;		
		$date_expenses .= substr($final_tweet[$k][created_at],3,4).",";	
	}
	
	
	

	}

	}

	
$myObj->food = $food;
$myObj->travel = $travel;
$myObj->entertainment = $entertainment;
$myObj->expenses = $expenses;

$myJSON = json_encode($myObj);

//echo $myJSON;
	
?>
<html>
  <head>
    <script type="text/javascript"
src="https://www.gstatic.com/charts/loader.js"></script>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart','bar']});
      google.charts.setOnLoadCallback(drawChart);
//google.charts.setOnLoadCallback(drawTimelineChart);
google.charts.setOnLoadCallback(drawBarChart);
     function drawChart() {
		  
		  var food = parseInt(document.getElementById("food").value);
		  var travel=parseInt(document.getElementById("travel").value);
		  var entertainment=parseInt(document.getElementById("entertainment").value);
		  var expenses=parseInt(document.getElementById("expenses").value);
		  var texthide=parseInt(document.getElementById("texthide").value);
			if(texthide==1){
				 var data = google.visualization.arrayToDataTable([
          ['Topic', 'Spending'],
          ['Travel',     travel],
          ['Food',      food],
          ['Entertainment',  entertainment],
          ['Expenses', expenses]
        
        ]);
 var twitterName=document.getElementById("Twittername").value
        var options = {
           title: 'Spending Patterns of '+twitterName+' By Over All',
           
        };

        var chart = new
google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
			}
			
       
      }
	 
	 
	 function drawBarChart() { 
	 if(document.getElementById("date_expenses").value!="") {
	 var date_expenses = document.getElementById("date_expenses").value;
	 if(date_expenses.match(/Sep/g)!=null) 
	 var res_sep = date_expenses.match(/Sep/g).length;
		if(date_expenses.match(/Aug/g)!=null)
	 var res_aug = date_expenses.match(/Aug/g).length;
		if(date_expenses.match(/Jul/g)!=null)
	 var res_jul = date_expenses.match(/Jul/g).length;
		if(date_expenses.match(/Jun/g)!=null)
	 var res_jun = date_expenses.match(/Jun/g).length;
	 }
	 if(document.getElementById("food_expenses").value!="") {
	 var food_expenses = document.getElementById("food_expenses").value;
 if(food_expenses.match(/Sep/g)!=null)	 
	 var food_sep = food_expenses.match(/Sep/g).length;
 if(food_expenses.match(/Aug/g)!=null)
	 var food_aug = food_expenses.match(/Aug/g).length;
 if(food_expenses.match(/Jul/g)!=null)
	 var food_jul = food_expenses.match(/Jul/g).length;
 if(food_expenses.match(/Jun/g)!=null)
	 var food_jun = food_expenses.match(/Jun/g).length;
	 }
	 
	 if(document.getElementById("travel_expenses").value!="") {
	  var travel_expenses = document.getElementById("travel_expenses").value;
if(travel_expenses.match(/Sep/g)!=null)	  
	 var tra_sep = travel_expenses.match(/Sep/g).length;
 if(travel_expenses.match(/Aug/g)!=null)
	 var tra_aug = travel_expenses.match(/Aug/g).length;
 if(travel_expenses.match(/Jul/g)!=null)
	 var tra_jul = travel_expenses.match(/Jul/g).length;
 if(travel_expenses.match(/Jun/g)!=null)
	 var tra_jun = travel_expenses.match(/Jun/g).length;
	 }
	 if(document.getElementById("entertainment_expenses").value!="") {
	  var entertainment_expenses = document.getElementById("entertainment_expenses").value;	  
	  if(entertainment_expenses.match(/Sep/g)!=null)
	 var ent_sep = entertainment_expenses.match(/Sep/g).length;
 if(entertainment_expenses.match(/Aug/g)!=null)
	 var ent_aug = entertainment_expenses.match(/Aug/g).length;
 if(entertainment_expenses.match(/Jul/g)!=null)
	 var ent_jul = entertainment_expenses.match(/Jul/g).length;
 if(entertainment_expenses.match(/Jun/g)!=null)
	 var ent_jun = entertainment_expenses.match(/Jun/g).length;
	 }
 


		 
		 
		 var texthide=parseInt(document.getElementById("texthide").value);
		 var twitterName=document.getElementById("Twittername").value
			if(texthide==1){
				 var data = google.visualization.arrayToDataTable([
          ['Month', 'Travel', 'Food', 'Entertainment','Expenses'],
          ['JUN', tra_jun,food_jun,ent_jun,res_jun],
          ['JUL', tra_jul,food_jul, ent_jul,res_jul],
          ['AUG', tra_aug,food_aug, ent_aug,res_aug],
          ['SEP', tra_sep,food_sep, ent_sep,res_sep]
        ]);

        var options = {
          chart: {
            title: 'Spending Patterns By Month',
            subtitle: 'Spending Patterns of '+twitterName+' for Jun-Sep ',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
			}
       
      }
	 
    </script>
  </head>
  <body>
 
  <form action="index.php" method="post">
  <div style="margin-left:35%;margin-top:25px;">
<b>Twitter name:</b> <input type="text" name="Twittername" id="Twittername" value=<?php echo $_REQUEST['Twittername'];?>>

<input type="submit" >
</div>
</form>
   <div class="container">
   <div class="row" >
   <div id="piechart" style=".col-md-6.col-xs-6;height:500px;"></div>
   <!--<div id="timeline" style=".col-md-6.col-xs-6"></div>-->
   </div>
   <div class="row">
<div id="columnchart_material" style=".col-md-6.col-xs-6; height: 500px;"></div> 
 </div>
   
   <div>
	<input type="hidden" value="<?php echo $food;?>" id="food"/>
	<input type="hidden" value="<?php echo $travel;?>" id="travel"/>
	<input type="hidden" value="<?php echo $entertainment;?>" id="entertainment"/>
	
	<input type="hidden" value="<?php echo $texthide;?>" id="texthide"/>
	
	<input type="hidden" value="<?php echo $expenses;?>" id="expenses"/>
	
	<input type="hidden" value="<?php echo $food_expenses;?>" id="food_expenses"/>
	<input type="hidden" value="<?php echo $travel_expenses;?>" id="travel_expenses"/>
	<input type="hidden" value="<?php echo $entertainment_expenses;?>" id="entertainment_expenses"/>
	<input type="hidden" value="<?php echo $date_expenses;?>" id="date_expenses"/>
	
  </body>
</html>


