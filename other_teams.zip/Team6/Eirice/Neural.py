import time
import Voice
import datetime
import duckduckgo as dg
from Voice import Voice
from subprocess import Popen
import subprocess
from Facebook import fb as fb
from HttpReq import RaiseRequest as rq
from Intelligence import Intelligence as I

class Impulses:
    
    def enrollmentreg(self, name, age, patientdob, benefittype):
        return rq.enrollmentreg(name, age, patientdob, benefittype)

    def claimreg(self, patientid, healthissue, claimdos, causeofproblem, hospital):
        return rq.claimreg(patientid, healthissue, claimdos, causeofproblem, hospital)

    def eligibilitycheck(self, benefittype, age, salary, disease):
        return rq.eligibilitycheck(benefittype, age, salary, disease)

    def claimstatuscheck(self, claimid):
        return rq.claimstatuscheck(claimid)

    def converse(self, string, path):
        voice = Voice()
        res = I.converse(self,string)
        if(res != ""):
            voice.speak(res, path)
