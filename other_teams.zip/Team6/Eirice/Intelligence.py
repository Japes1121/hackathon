import urllib.request

class Intelligence:
    def converse(self, request):
        request = str(request).replace(" ","%20")
        response = str(urllib.request.urlopen("http://share-auto.co:5001/request/?query="+request).read()).replace("b'", "")
        print(response)
        response = ''.join(e for e in response if (e.isalnum() or e==" " or e=="."))
        print(response)
        return response
