#import packages
import os
import vlc
import time
from gtts import gTTS
from mutagen.mp3 import MP3

class Voice:       
    def speak(self, string, path):
        instance = vlc.Instance()
        player = instance.media_player_new()    
        print("speak called")
        tts = gTTS(text = string, lang = "en")
        tts.save(path+"\\speech.mp3")
        audio = path+"\\speech.mp3"
        mp3audio = MP3(path+"\\speech.mp3")
        media = instance.media_new(audio)
        media.get_mrl()
        player.set_media(media)
        player.play()
        duration = mp3audio.info.length
        time.sleep(duration)
