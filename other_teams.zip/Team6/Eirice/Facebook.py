# -*- coding: utf-8-*-
import re
import facebook


class fb:
    def checknotification():    
        #oauth_access_token = 'EAACEdEose0cBALXZCAZCC6AIFAt5XOimNfZBYgEEdY17eMvuwkIvWTRGUGBk7IEWo9ZAjIPxaFPNi6UItSKlgXZCJtywIp0V5nwROBmRTATpqOyz4PT4ihvQOf2X9nUqnU29VgeZCgupYkZBNueL96jvs6GirAWZC0QyyWvRFym2adCrnu1ySHP9stx9MJn3BK4ZD'
        graph = facebook.GraphAPI(access_token='EAACEdEose0cBABvaSj22Ve0uE8LhBoWznZBuQDSZCpu7yzF1gCOGq3uInAMmyiFSjVpgJBcXAbXZAAy6vnvSVb717nZC0x4xXWVGJg1qWS5PFz2cVVY7exOZAdhOR1AU1YvkpTzWrPZA7juFSIfo7Dy8sZAZCCmoY1vPa7dZAeZAyXbgkwRaBhIvMlMvpnwp9atu0ZD',version='2.2')
        #graph = facebook.GraphAPI(access_token=oauth_access_token,version='2.2')
        try:
            results = graph.request("me/notifications")
            if not len(results['data']):
                res = "You have no Facebook notifications"
            updates = []
            for notification in results['data']:
            #updates.append(notification['title'])
                count = len(results['data'])
            res = "You have " + str(count) +" Facebook notifications"
            return res
        except facebook.GraphAPIError:
            res = "I have not been authorized to query your Facebook. If you " + "would like to check your notifications in the future, " +"please visit the Jasper dashboard."
            return res
        except:
            res = "I apologize, there's a problem with that service at the moment"
            return res
    #def getnotification(self,order):
        
