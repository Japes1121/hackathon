#import packages
import os
import vlc
import time
from gtts import gTTS
from Voice import Voice
from mutagen.mp3 import MP3
from Neural import Impulses
import speech_recognition as sr



#Define necessary variables
voice = Voice()
recognizer = sr.Recognizer()
recognizer.dynamic_energy_threshold = False
recognizer.energy_threshold = 400
recognizer.phrase_timeout = 3
print("Defining")
print("Initializing speech recognizer...")
currentpath = os.getcwd()
r = sr.Recognizer()
print("Initializing mp3 player...")
impulses = Impulses()
audio = currentpath+"\\Welcome.mp3"
response = currentpath+"\\Yes.mp3"


#Welcome
tts = gTTS(text="Hello, Welcome to We care healthcare. I am your personal health assistant Eirice. Please let me know how I can help you.", lang="en")
#tts = gTTS(text="Hello", lang="en")
ttyes = gTTS(text="Yes", lang="en")
print("Saving mp3 file...")
tts.save(currentpath+"\\Welcome.mp3")
ttyes.save(currentpath+"\\Yes.mp3")
print(currentpath+"\\Welcome.mp3")
print("Saved mp3 file...")
print("Playing mp3 file...")
#os.startfile(currentpath+"\\Welcome.mp3")
mp3audio = MP3(currentpath+"\\Welcome.mp3")
yesaudio = MP3(currentpath+"\\Yes.mp3")

instance = vlc.Instance()
player = instance.media_player_new()
media = instance.media_new(audio)
media.get_mrl()
player.set_media(media)

newplayer = instance.media_player_new()
responsemedia = instance.media_new(response)
responsemedia.get_mrl()
newplayer.set_media(responsemedia)

player.play()
duration = mp3audio.info.length #/ 1000
time.sleep(duration)

def listen():
    with sr.Microphone() as source:
        audio = recognizer.listen(source)
        phrase = recognizer.recognize_google(audio)
        return phrase

def init():    
    with sr.Microphone() as source:        
        print("listening")
        audio = recognizer.listen(source)
        print("Finsihed listen")
        try:            
            phrase = recognizer.recognize_google(audio)
            flag = True
            print("second:"+str(phrase))
        except sr.UnknownValueError:
            print("Could not understand")
            flag = False
        except sr.RequestError as e:
            print("Recog Error: {0}", format(e))
            flag = False
        if flag:
            trimmedstring = phrase.lower().replace(" ", "")
            if (("register" in trimmedstring and ("ment" in trimmedstring or "men" in trimmedstring) or ("buy" in trimmedstring and ("policy" in trimmedstring or "ment" in trimmedstring or "men" in trimmedstring)))):
                voice.speak("I understand that you want to register your enrollment. Please tell me the details as I ask you one by one", currentpath)
                voice.speak("I am going to start now. What is your name", currentpath)
                name = listen()
                print(name)
                voice.speak("What is your age", currentpath)
                age = listen()
                print(age)
                voice.speak("What is your date of birth", currentpath)
                patientdob = listen()
                print(patientdob)
                voice.speak("What is your preferred policy name", currentpath)
                benefittype = listen()
                print(benefittype)
                res = impulses.enrollmentreg(name, age, patientdob, benefittype)
                if "Ins" in res:
                    voice.speak("You are successfully registered with our Healthcare system. Your status is currently Inititated. One of our agents will soon contact you to get further details", currentpath)
            elif "register" in trimmedstring and ("laim" in trimmedstring or "lan" in trimmedstring):
                voice.speak("I understand that you want to register your claim. I apologize beforehand, since this might take a little time. You need to keep your patientid and other details ready. Do you need more time?", currentpath)
                #voice.speak("I understand that you want to register your claim. I apologize beforehand, since this might take a little time. Please keep your patientid and other details ready.", currentpath)
                #res = listen()
                #if "yes" in res:
                #    if "minutes" in res:
                voice.speak("I am going to start now. What is your patientid", currentpath)
                patientid = listen()
                voice.speak("What type of service are you claiming against for? Medical or Pharmacy?", currentpath)
                healthissue = listen()
                voice.speak("Can you tell me when you availed this service?", currentpath)
                claimdos = listen()
                voice.speak("Can you tell me why you had to avail this service? What is the cause?", currentpath)
                causeofproblem = listen()
                voice.speak("Please tell me the institution where you had availed this service", currentpath)
                hospital = listen()                
                voice.speak("I have recorded all the mentioned details. Thank you for your patientce. I also want you to upload any image of the bill you have for our verification. I will trigger a message to your registered mobile, kindly upload any available image through the link.", currentpath)
                res = impulses.claimreg(patientid, healthissue, claimdos, causeofproblem, hospital)
                voice.speak("Your claim has been raised in our Healthcare system. Your claims status is currently Open. One of our agents will soon contact you to get further details", currentpath)            
            elif "status" in trimmedstring and ("laim" in trimmedstring or "lan" in trimmedstring):
                voice.speak("To check your Claim status, please tell your claimid", currentpath)
                claimid = listen()
                trimmedclaimid = claimid.replace(" ", "").replace("to", "2").replace("too", "2").replace("free", "3")
                print(trimmedclaimid)
                claimstatus = impulses.claimstatuscheck(trimmedclaimid)
                if "No" in claimstatus:
                    voice.speak("Your claimid is invalid", currentpath)
                else:
                    voice.speak("You claim is in "+claimstatus+" status", currentpath)
            else:
                impulses.converse(phrase, currentpath)
                
        return
loopflag = True
while loopflag == True:
    init()
    voice.speak("Is there anything else I can do for you today?", currentpath)
    response = listen()
    print(response)
    if "No" in response or "no" in response:
        loopflag = False
        voice.speak("Thank you for calling us. We would look forward to serving you", currentpath)
    else:
        voice.speak("What to do you want me to help you with?", currentpath)
