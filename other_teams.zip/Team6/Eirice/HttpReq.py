from urllib.parse import urlencode
from urllib.request import Request, urlopen


class RaiseRequest:
    def enrollmentreg(name, age, patientdob, benefittype):
        url = 'http://128.199.181.162:8083/register/'
        post_fields = {'name':name, 'age':age, 'patientdob':patientdob, 'benefittype':benefittype}
        request = Request(url, urlencode(post_fields).encode())
        json = urlopen(request).read().decode()
        return str(json)

    def claimreg(patientid, healthissue, claimdos, causeofproblem, hospital):
        url = 'http://128.199.181.162:8083/post_claim/'
        post_fields = {'patientid':patientid, 'healthissue':healthissue, 'claimdos':claimdos, 'causeofproblem':causeofproblem, 'hospital':hospital}
        request = Request(url, urlencode(post_fields).encode())
        json = urlopen(request).read().decode()
        return str(json)

    def eligibilitycheck(benefittype, age, salary, disease):
        url = 'http://128.199.181.162:8083/eligibility_status_check/'
        post_fields = {'benefit': benefittype, 'age': age, 'salary':salary, 'disease':disease}
        request = Request(url, urlencode(post_fields).encode())
        json = urlopen(request).read().decode()
        return str(json)

    def claimstatuscheck(claimid):
        url = 'http://128.199.181.162:8083/get_claim_status/'
        post_fields = {'claimid':claimid}
        request = Request(url, urlencode(post_fields).encode())
        json = urlopen(request).read().decode()
        return str(json)
